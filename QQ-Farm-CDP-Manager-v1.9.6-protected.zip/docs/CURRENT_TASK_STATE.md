# Current Task State

## Task

v1.9.6 protected follow-up: protected service status stability, desktop diagnostics,
encoding/mojibake checks, QQ real-runtime verification, and agent policy updates.

## Current Stage

- Final pre-release verification completed for build id `PUBLIC-20260618-003`.
- Port 8787 test instance was stopped after runtime verification and confirmed clean.
- Protected package under test: `F:\QQ-Farm-Protected-Tests\v1.9.6-PUBLIC-20260618-003`.
- Source workspace: `E:\QQ-Farm-CDP-Manager-opt`.

## Completed

- Task attachment re-read on 2026-06-18.
- AGENTS.md re-read on 2026-06-18.
- AI_AGENT_POLICY.md re-read on 2026-06-18.
- Current git status checked on 2026-06-18.
- Compared source/protected `/api/health` and `/api/auto-farm` schema captures.
- Confirmed protected `/api/health` can exceed the old 1500 ms desktop timeout.
- Updated desktop service status handling to use a 5000 ms health timeout, stale-health grace,
  independent port PID detection, and layered ready fields.
- Added protected desktop status regression test and wired it into `release:dual` checks.
- Added desktop JSONL diagnostic writer and hooked auto-farm manager events into it.
- Added desktop diagnostics regression test and wired it into `release:dual` checks.
- Updated `AI_AGENT_POLICY.md` to clean English UTF-8 and changed release-integrity policy
  validation to require clean English public-benefit text instead of a legacy mojibake token.
- Added `scripts/scan-mojibake.cjs` and `docs/ENCODING_SCAN_REPORT.md`.
- `npm.cmd run release:dual -- --version 1.9.6 --dry-run --allow-dirty` passed with
  build id `PUBLIC-20260618-003`.
- Dry-run generated local protected test tree:
  `F:\QQ-Farm-Protected-Tests\v1.9.6-PUBLIC-20260618-003`.
- Protected runtime smoke test on port 8787 reached signed-core gateway health.
- Protected desktop `getSnapshot()` returned `service.running=true`, `phase=running`,
  `processAlive=true`, `httpReady=true`, `gatewayReady=true`, `schedulerReady=true`.
- Protected health latency sample on connected runtime: 20/20 success, max 1746 ms,
  avg 1094.6 ms, 6 samples over the old 1500 ms threshold.
- Protected diagnostics writer smoke test created `home-farm-trace.jsonl`.
- QQ-link launch attempt was executed once. After 20 seconds, protected health still reported
  `qqWs.connected=false`, `qq_ws_disconnected`, and `qqBundle.sync.status=target_outdated`.
- Restarting the protected test instance from the protected tree reloaded QQ Farm into the
  current bootstrap. Final status: `qq_ws_connected`, `gameCtl=ready`,
  `qq_runtime_context_ready`, `qqBundle.sync.status=runtime_synced`.
- Final active protected test instance: build id `PUBLIC-20260618-003`, port 8787,
  integrity `signed-core`.
- Real-runtime task verification on protected runtime:
  - `own_base`: `real_action_confirmed`.
  - `own_collect`: explicit no-op `home_harvest_due_not_detected`.
  - `own_plant`: explicit no-op `no_empty_lands`.
  - `friend_steal`: explicit no-op `stealable_state_empty`.
  - `friend_help`: `real_action_confirmed`.
  - `guard_dog_help`: explicit no-op `guarddog_action_not_available`.
- Desktop diagnostics generated all required trace files:
  `home-farm-trace.jsonl`, `friend-steal-trace.jsonl`, `normal-help-trace.jsonl`,
  `guarddog-action-trace.jsonl`, `scheduler-trace.jsonl`, `qq-runtime-trace.jsonl`,
  and `protected-status-trace.jsonl`.
- Latest attachment re-read on 2026-06-18 requested final candidate
  `v1.9.6-PUBLIC-20260618-003`, port 8787 cleanup, pre-release verification,
  changelog/docs sync, and no GitHub publish/tag/push before confirmation.
- Stopped 8787 listener PID 18996 and confirmed the port is clean.
- Verified candidate paths exist:
  - `release-output\private\v1.9.6-PUBLIC-20260618-003\QQ-Farm-CDP-Manager-v1.9.6-source.zip`
  - `release-output\public\v1.9.6-PUBLIC-20260618-003\QQ-Farm-CDP-Manager-v1.9.6-protected.zip`
  - `F:\QQ-Farm-Protected-Tests\v1.9.6-PUBLIC-20260618-003`
- `npm.cmd run release:verify` passed for the source workspace.
- `npm.cmd run release:verify -- release-output\private\v1.9.6-PUBLIC-20260618-003\QQ-Farm-CDP-Manager-v1.9.6-source.zip` passed.
- `npm.cmd run release:verify -- release-output\public\v1.9.6-PUBLIC-20260618-003\QQ-Farm-CDP-Manager-v1.9.6-protected.zip` passed.
- `npm.cmd run release:verify -- F:\QQ-Farm-Protected-Tests\v1.9.6-PUBLIC-20260618-003` passed.
- Protected package tests passed for tamper checks, runtime size, desktop status,
  desktop diagnostics, and docs-only mojibake scan.
- Updated CHANGELOG, README, AGENTS, and AI_AGENT_POLICY with v1.9.6-003
  status/diagnostics/UTF-8 release rules. These source docs were updated after
  candidate package generation to avoid changing the requested `003` build id.

## Pending

- Optional follow-up: migrate remaining legacy mojibake UI/log strings in `public/index.html`
  and `src/auto-farm-manager.js` as a separate focused task.

## Blocked

- None for protected QQ runtime verification. Some actions were unavailable in-game and have
  explicit no-op reasons as listed above.

## Last Modified Files

- `desktop-sample/service-controller.js`
- `src/desktop-diagnostics.js`
- `src/auto-farm-manager.js`
- `scripts/test-protected-desktop-status.cjs`
- `scripts/test-desktop-diagnostics.cjs`
- `scripts/scan-mojibake.cjs`
- `scripts/dual-release.cjs`
- `scripts/test-protected-release.cjs`
- `src/release-integrity.js`
- `AGENTS.md`
- `AI_AGENT_POLICY.md`
- `docs/ENCODING_SCAN_REPORT.md`
- `docs/CURRENT_TASK_STATE.md`

## Tests Run

- `node --check desktop-sample/service-controller.js`
- `node --check src/desktop-diagnostics.js`
- `node --check src/auto-farm-manager.js`
- `node --check scripts/test-desktop-diagnostics.cjs`
- `node scripts/test-protected-desktop-status.cjs`
- `node scripts/test-desktop-diagnostics.cjs`
- `node scripts/test-desktop-runtime-switch.cjs`
- `node scripts/test-auto-farm-scheduler-protocol.cjs`
- `node scripts/test-auto-plant-fast-path.cjs`
- `node scripts/test-multi-tile-auto-plant.cjs`
- `node scripts/test-auto-fertilizer-purple-land.cjs`
- `node scripts/test-friend-guard-dog.cjs`
- `node scripts/test-friend-guard-dog-context-cache.cjs`
- `node scripts/test-friend-guard-dog-priority.cjs`
- `node scripts/test-health-payload-cost.cjs`
- `node scripts/test-friend-status-watcher-cost.cjs`
- `node scripts/test-preview-recovery.cjs`
- `node scripts/scan-mojibake.cjs --docs-only --fail`
- `npm.cmd run release:dual -- --version 1.9.6 --dry-run --allow-dirty`
- Protected runtime smoke: `GET http://127.0.0.1:8787/api/health`
- Protected desktop smoke: `desktop-sample/service-controller.getSnapshot()`
- Protected diagnostics smoke: `src/desktop-diagnostics.createDesktopDiagnosticWriter()`

## Next Action

Wait for user confirmation before any GitHub publish/tag/push/release action.
Do not regenerate packages unless the user accepts a new build id.

## Boundaries

- Do not modify `wmpf/`, `wmpf/frida/`, `hook.js`, `addresses.*.json`, WMPF patch scenes,
  or ExtraPatchSceneNumbers.
- Do not publish, create tags/releases, or push the public repository for this task.
