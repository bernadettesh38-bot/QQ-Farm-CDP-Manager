﻿# Current Task State

## Active Release Task: v2.0

Completed changes:

- Version bumped to 2.0.0.
- Removed the v1.9.9 warehouse open/close and lightweight in-game idle keepalive behavior from the active path.
- button.js runIdleDisconnectKeepAlive now returns a skipped/replaced result and does not click or open warehouse.
- button-lite.js rebuilt from the new source.
- Gateway idleDisconnectWatch compatibility config now drives service-side scheduledWindowRelaunch instead of runtime gameCtl keepalive sync.
- Scheduled relaunch is fixed to 90 minutes, including old local configs that still contain 150.
- Gateway health exposes scheduledWindowRelaunch state.
- QQ RPC allowlist entries for gameCtl.runIdleDisconnectKeepAlive, gameCtl.setIdleDisconnectWatchEnabled, and gameCtl.getIdleDisconnectWatchState were removed.
- Added Windows helpers to kill windows by title/process and launch the desktop QQ Classic Farm shortcut.
- performRuntimeRestart now uses restartQqMiniappHost for QQ and kill-window plus desktop shortcut for WX, with old WX protocol/command paths as fallback.
- Desktop WX service start now waits for /api/health and then waits for WX miniapp bridge/context waiting state before launching the shortcut.
- Protected obfuscation profile no longer uses base64 string-array encoding or self-defending dynamic execution helpers; protected leak scan rejects callable decode/dynamic execution helpers.
- README, CHANGELOG, AGENTS, and AI_AGENT_POLICY updated for v2.0 behavior.

Verification completed:

- JS syntax checks passed for gateway, process guard files, desktop service-controller, button.js, button-lite.js, release-lib.
- node scripts/test-idle-disconnect-watch.cjs passed.
- node scripts/test-scheduled-window-relaunch.cjs passed.
- node scripts/test-protected-hardening.cjs passed.
- node scripts/test-user-settings-persistence.cjs passed.
- node scripts/test-desktop-runtime-switch.cjs passed.
- docs-only mojibake scan passed.
- Desktop WX startService('wx') live path started service, reached CDP waiting_miniapp/context_timeout state, and recorded wxShortcutLaunch.ok=true.
- Normal Windows_start.bat --qq live path started service on 127.0.0.1:8787 and health showed scheduledWindowRelaunch.intervalMin=90.
- Final dry-run passed: npm.cmd run release:dual -- --version 2.0 --dry-run --allow-dirty.
- Dry-run build id: PUBLIC-20260623-008.
- Manifest verification, sensitive scan, public leak scan, tamper tests, protected runtime size tests, scheduled relaunch tests, and protected hardening tests passed.
- Local protected test copy was skipped because F:\QQ-Farm-Protected-Tests is unavailable.

Pending:

- Commit private source changes.
- Run formal npm.cmd run release:dual -- --version 2.0 from a clean worktree.
- Confirm public protected branch/tag/release upload completes.

Boundaries:

- Do not modify wmpf/, wmpf/frida/, wmpf/frida/config/addresses.*.json, wmpf/frida/hook.js, WMPF patch scenes, or ExtraPatchSceneNumbers.
- Source artifacts remain private; public repo receives protected artifacts only.
