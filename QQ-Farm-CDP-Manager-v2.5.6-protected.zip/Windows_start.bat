@REM Public benefit build. Read README before redistribution.
@echo off
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul
set "PYTHONUTF8=1"
set "NPM_CONFIG_UNICODE=true"

title QQ Farm Auto - Start

where node >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Node.js was not found. Please install Node.js 22 or newer.
    echo Download: https://nodejs.org/
    pause
    exit /b 1
)

set "FARM_LAUNCH_TARGET_PLATFORM=windows"
node start-entry.cjs %*

endlocal
