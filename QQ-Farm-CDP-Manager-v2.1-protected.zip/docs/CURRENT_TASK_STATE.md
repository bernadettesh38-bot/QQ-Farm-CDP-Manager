﻿# Current Task State

## v2.0 Published

Release result:

- GitHub Release: https://github.com/bernadettesh38-bot/QQ-Farm-CDP-Manager/releases/tag/v2.0
- Public branch: protected-release
- Public tag: v2.0
- Build id: PUBLIC-20260623-010
- Source commit used by release: ce5d0c50eac4b4790212a6d37eca5e1325911638

Artifacts:

- Public protected package: release-output/public/v2.0-PUBLIC-20260623-010/QQ-Farm-CDP-Manager-v2.0-protected.zip
- Private source package: release-output/private/v2.0-PUBLIC-20260623-010/QQ-Farm-CDP-Manager-v2.0-source.zip
- Public GitHub assets: protection-manifest.json, protection-manifest.sig, public-key.pem, QQ-Farm-CDP-Manager-v2.0-protected.sha256, QQ-Farm-CDP-Manager-v2.0-protected.zip

Completed changes:

- Removed the v1.9.9 warehouse open/close and lightweight in-game idle keepalive behavior from the active path.
- button.js runIdleDisconnectKeepAlive now returns a skipped/replaced result and does not click or open warehouse.
- button-lite.js rebuilt from the new source.
- Gateway idleDisconnectWatch compatibility config now drives service-side scheduledWindowRelaunch instead of runtime gameCtl keepalive sync.
- Scheduled relaunch is fixed to 90 minutes, including old local configs that still contain 150.
- Gateway health exposes scheduledWindowRelaunch state.
- QQ RPC allowlist entries for gameCtl.runIdleDisconnectKeepAlive, gameCtl.setIdleDisconnectWatchEnabled, and gameCtl.getIdleDisconnectWatchState were removed.
- Added Windows helpers to kill windows by title/process and launch the desktop QQ Classic Farm shortcut.
- performRuntimeRestart now uses restartQqMiniappHost for QQ and kill-window plus desktop shortcut for WX, with old WX protocol/command paths as fallback.
- Desktop WX service start now waits for /api/health and then waits for WX miniapp bridge/context waiting state before launching the shortcut.
- qq-host.js no longer uses Function("return this") for global detection.
- Protected obfuscation profile no longer uses base64 string-array encoding or self-defending dynamic execution helpers; protected leak scan rejects callable decode/dynamic execution helpers.
- README, CHANGELOG, AGENTS, and AI_AGENT_POLICY updated for v2.0 behavior.

Verification completed:

- Formal npm.cmd run release:dual -- --version 2.0 passed.
- Manifest verification, sensitive scan, public leak scan, tamper tests, protected runtime size tests, scheduled relaunch tests, and protected hardening tests passed.
- Desktop WX startService('wx') live path started service, reached CDP waiting_miniapp/context_timeout state, and recorded wxShortcutLaunch.ok=true.
- Normal Windows_start.bat --qq live path started service on 127.0.0.1:8787 and health showed scheduledWindowRelaunch.intervalMin=90.
- Local protected test copy was skipped because F:\QQ-Farm-Protected-Tests is unavailable.

Boundaries kept:

- No WMPF/Frida paths were modified.
- Source artifacts remain private; public repo received protected artifacts only.

## v2.1 In Progress

Requested fixes:

- The 90-minute scheduled game-window relaunch must kill/close only the current miniapp/game window and relaunch the miniapp. It must not restart the local service.
- The relaunch is not considered successful until the selected runtime is ready again. QQ requires WebSocket host plus `gameCtl` readiness; WX requires `cdp.contextReady`. If readiness is not restored, recovery must keep retrying instead of waiting for the next 90-minute cycle.
- Add an immediate debug button for the scheduled relaunch path so the same window kill/relaunch behavior can be tested on demand.
- WeChat desktop startup must start the service first, wait for the gateway to reach the miniapp debug-bridge/context waiting state, launch the desktop shortcut, and if context readiness still times out, automatically kill the old WeChat miniapp window and relaunch once.

Implemented so far:

- `desktop-sample/service-controller.js` now waits for WX context readiness after shortcut launch and automatically performs one CDP runtime window relaunch retry through `performRuntimeRestart(..., "cdp")` when the first launch does not reach context readiness.
- `src/gateway.js` now exposes `POST /api/scheduled-window-relaunch/run-now`, which calls the scheduled relaunch executor with `force: true` and does not go through the process-guard service restart route.
- `src/gateway.js` now waits for QQ/WX runtime readiness after scheduled relaunch. If QQ `gameCtl` or WX `cdp.contextReady` is not restored, it records `runtime_not_ready_after_relaunch` and schedules a 30-second recovery retry while keeping the service process alive.
- `src/process-guard.js` now normalizes legacy corrupted window titles such as `QQ??????` back to `QQ经典农场` so old miniapp windows can be found and closed.
- `desktop-sample/service-controller.js` now triggers the gateway background scheduled-window-relaunch recovery loop when desktop WX startup still ends in `wx_context_timeout` after its immediate retry.
- `public/index.html` now includes an immediate scheduled-window-relaunch debug button.
- Regression tests verify the new API/UI route and the WX service-start -> bridge-wait -> shortcut-launch -> context-ready/relaunch sequence.
- `package.json`, README, CHANGELOG, AGENTS, and AI_AGENT_POLICY have been updated for v2.1.

Verification so far:

- `node --check desktop-sample/service-controller.js`
- `node --check src/gateway.js`
- `node scripts/test-scheduled-window-relaunch.cjs`
- `node scripts/test-desktop-runtime-switch.cjs`
- `node scripts/test-idle-disconnect-watch.cjs`
- `node scripts/test-protected-hardening.cjs`
- `node scripts/test-process-guard-cooldown.cjs`
- `node scripts/scan-mojibake.cjs --docs-only --fail`
- `npm.cmd run release:dual -- --version 2.1 --dry-run --allow-dirty` passed with protected artifact verification, sensitive scan, public leak scan, and tamper tests. Latest dry-run build id was `PUBLIC-20260624-002`.
- Live WX desktop-controller startup reached service pid `15348`, launched the desktop shortcut, failed initial `cdp.contextReady`, triggered `backgroundRecovery.ok=true`, and the gateway scheduled `scheduled_window_relaunch_recovery_retry` with `recoveryAttemptCount=1` while keeping the same service pid alive.
- Live QQ `Windows_start.bat --qq` startup reached `qq_ws_connected` and `qq_runtime_context_ready`. Manual scheduled-window relaunch returned `runtime_ready_after_relaunch`, `readiness.reason=qq_runtime_ready`, `recoveryAttemptCount=0`, and kept the same 8787 service pid alive.

Still to do:

- Generate and publish the protected v2.1 release after verification passes.
