"use strict";

const WMPF_ADDRESS_OVERRIDES = Object.freeze({
  19201: Object.freeze({
    Version: 19201,
    LoadStartHookOffset: "0x25B5DD0",
    CDPFilterHookOffset: "0x301B3C0",
    SceneOffsets: Object.freeze([1376, 1312, 456]),
  }),
  20001: Object.freeze({
    Version: 20001,
    LoadStartHookOffset: "0x25D1520",
    CDPFilterHookOffset: "0x30B03A0",
    SceneOffsets: Object.freeze([64, 1480, 8, 1416, 16, 456]),
  }),
  20005: Object.freeze({
    Version: 20005,
    LoadStartHookOffset: "0x25DBBE0",
    CDPFilterHookOffset: "0x30C5D90",
    SceneOffsets: Object.freeze([64, 1480, 8, 1416, 16, 456]),
  }),
  25047: Object.freeze({
    Version: 25047,
    LoadStartHookOffset: "0x29EF320",
    CDPFilterHookOffset: "0x3859AE0",
    SceneOffsets: Object.freeze([64, 1488, 8, 1424, 16, 456]),
  }),
});

function getWmpfAddressOverride(version) {
  const key = Number(version);
  const value = WMPF_ADDRESS_OVERRIDES[key];
  if (!value) return null;
  return {
    Version: value.Version,
    LoadStartHookOffset: value.LoadStartHookOffset,
    CDPFilterHookOffset: value.CDPFilterHookOffset,
    SceneOffsets: Array.from(value.SceneOffsets),
  };
}

module.exports = {
  WMPF_ADDRESS_OVERRIDES,
  getWmpfAddressOverride,
};
