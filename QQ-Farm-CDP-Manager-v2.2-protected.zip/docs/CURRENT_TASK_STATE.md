﻿# Current Task State

## v2.0 Published

Release result:

- GitHub Release: https://github.com/bernadettesh38-bot/QQ-Farm-CDP-Manager/releases/tag/v2.0
- Public branch: protected-release
- Public tag: v2.0
- Build id: PUBLIC-20260623-010
- Source commit used by release: ce5d0c50eac4b4790212a6d37eca5e1325911638

Artifacts:

- Public protected package: release-output/public/v2.0-PUBLIC-20260623-010/QQ-Farm-CDP-Manager-v2.0-protected.zip
- Private source package: release-output/private/v2.0-PUBLIC-20260623-010/QQ-Farm-CDP-Manager-v2.0-source.zip
- Public GitHub assets: protection-manifest.json, protection-manifest.sig, public-key.pem, QQ-Farm-CDP-Manager-v2.0-protected.sha256, QQ-Farm-CDP-Manager-v2.0-protected.zip

Completed changes:

- Removed the v1.9.9 warehouse open/close and lightweight in-game idle keepalive behavior from the active path.
- button.js runIdleDisconnectKeepAlive now returns a skipped/replaced result and does not click or open warehouse.
- button-lite.js rebuilt from the new source.
- Gateway idleDisconnectWatch compatibility config now drives service-side scheduledWindowRelaunch instead of runtime gameCtl keepalive sync.
- Scheduled relaunch is fixed to 90 minutes, including old local configs that still contain 150.
- Gateway health exposes scheduledWindowRelaunch state.
- QQ RPC allowlist entries for gameCtl.runIdleDisconnectKeepAlive, gameCtl.setIdleDisconnectWatchEnabled, and gameCtl.getIdleDisconnectWatchState were removed.
- Added Windows helpers to kill windows by title/process and launch the desktop QQ Classic Farm shortcut.
- performRuntimeRestart now uses restartQqMiniappHost for QQ and kill-window plus desktop shortcut for WX, with old WX protocol/command paths as fallback.
- Desktop WX service start now waits for /api/health and then waits for WX miniapp bridge/context waiting state before launching the shortcut.
- qq-host.js no longer uses Function("return this") for global detection.
- Protected obfuscation profile no longer uses base64 string-array encoding or self-defending dynamic execution helpers; protected leak scan rejects callable decode/dynamic execution helpers.
- README, CHANGELOG, AGENTS, and AI_AGENT_POLICY updated for v2.0 behavior.

Verification completed:

- Formal npm.cmd run release:dual -- --version 2.0 passed.
- Manifest verification, sensitive scan, public leak scan, tamper tests, protected runtime size tests, scheduled relaunch tests, and protected hardening tests passed.
- Desktop WX startService('wx') live path started service, reached CDP waiting_miniapp/context_timeout state, and recorded wxShortcutLaunch.ok=true.
- Normal Windows_start.bat --qq live path started service on 127.0.0.1:8787 and health showed scheduledWindowRelaunch.intervalMin=90.
- Local protected test copy was skipped because F:\QQ-Farm-Protected-Tests is unavailable.

Boundaries kept:

- No WMPF/Frida paths were modified.
- Source artifacts remain private; public repo received protected artifacts only.

## v2.1 Published

Release result:

- GitHub Release: https://github.com/bernadettesh38-bot/QQ-Farm-CDP-Manager/releases/tag/v2.1
- Public branch: protected-release
- Public tag: v2.1
- Build id: PUBLIC-20260624-003
- Source commit used by release: 77640b48ee7afeb0fecc7eddfaba00d72b520f78

Artifacts:

- Public protected package: release-output/public/v2.1-PUBLIC-20260624-003/QQ-Farm-CDP-Manager-v2.1-protected.zip
- Private source package: release-output/private/v2.1-PUBLIC-20260624-003/QQ-Farm-CDP-Manager-v2.1-source.zip
- Public GitHub assets: protection-manifest.json, protection-manifest.sig, public-key.pem, QQ-Farm-CDP-Manager-v2.1-protected.sha256, QQ-Farm-CDP-Manager-v2.1-protected.zip

Completed changes:

- The 90-minute scheduled game-window relaunch must kill/close only the current miniapp/game window and relaunch the miniapp. It must not restart the local service.
- The relaunch is not considered successful until the selected runtime is ready again. QQ requires WebSocket host plus `gameCtl` readiness; WX requires `cdp.contextReady`. If readiness is not restored, recovery must keep retrying instead of waiting for the next 90-minute cycle.
- Add an immediate debug button for the scheduled relaunch path so the same window kill/relaunch behavior can be tested on demand.
- WeChat desktop startup must start the service first, wait for the gateway to reach the miniapp debug-bridge/context waiting state, launch the desktop shortcut, and if context readiness still times out, automatically kill the old WeChat miniapp window and relaunch once.

- `desktop-sample/service-controller.js` now waits for WX context readiness after shortcut launch and automatically performs one CDP runtime window relaunch retry through `performRuntimeRestart(..., "cdp")` when the first launch does not reach context readiness.
- `src/gateway.js` now exposes `POST /api/scheduled-window-relaunch/run-now`, which calls the scheduled relaunch executor with `force: true` and does not go through the process-guard service restart route.
- `src/gateway.js` now waits for QQ/WX runtime readiness after scheduled relaunch. If QQ `gameCtl` or WX `cdp.contextReady` is not restored, it records `runtime_not_ready_after_relaunch` and schedules a 30-second recovery retry while keeping the service process alive.
- `src/process-guard.js` now normalizes legacy corrupted window titles such as `QQ??????` back to `QQ经典农场` so old miniapp windows can be found and closed.
- `desktop-sample/service-controller.js` now triggers the gateway background scheduled-window-relaunch recovery loop when desktop WX startup still ends in `wx_context_timeout` after its immediate retry.
- `public/index.html` now includes an immediate scheduled-window-relaunch debug button.
- Regression tests verify the new API/UI route and the WX service-start -> bridge-wait -> shortcut-launch -> context-ready/relaunch sequence.
- `package.json`, README, CHANGELOG, AGENTS, and AI_AGENT_POLICY were updated for v2.1.

Verification completed:

- `node --check desktop-sample/service-controller.js`
- `node --check src/gateway.js`
- `node scripts/test-scheduled-window-relaunch.cjs`
- `node scripts/test-desktop-runtime-switch.cjs`
- `node scripts/test-idle-disconnect-watch.cjs`
- `node scripts/test-protected-hardening.cjs`
- `node scripts/test-process-guard-cooldown.cjs`
- `node scripts/scan-mojibake.cjs --docs-only --fail`
- `npm.cmd run release:dual -- --version 2.1 --dry-run --allow-dirty` passed with protected artifact verification, sensitive scan, public leak scan, and tamper tests. Latest dry-run build id was `PUBLIC-20260624-002`.
- Live WX desktop-controller startup reached service pid `15348`, launched the desktop shortcut, failed initial `cdp.contextReady`, triggered `backgroundRecovery.ok=true`, and the gateway scheduled `scheduled_window_relaunch_recovery_retry` with `recoveryAttemptCount=1` while keeping the same service pid alive.
- Live QQ `Windows_start.bat --qq` startup reached `qq_ws_connected` and `qq_runtime_context_ready`. Manual scheduled-window relaunch returned `runtime_ready_after_relaunch`, `readiness.reason=qq_runtime_ready`, `recoveryAttemptCount=0`, and kept the same 8787 service pid alive.

Release verification:

- Formal `npm.cmd run release:dual -- --version 2.1` passed.
- Manifest verification, sensitive scan, public leak scan, protected runtime size tests, and tamper tests passed.
- `gh release view v2.1` verified the public release URL and five uploaded assets.
- Local protected test copy was skipped because F:\QQ-Farm-Protected-Tests is unavailable.

Boundaries kept:

- No WMPF/Frida paths were modified.
- Source artifacts remain private; public repo received protected artifacts only.

## WX SouYiSou Launch Path In Progress

Current user-reported blocker:

- The desktop `QQ经典农场` shortcut can open the WeChat farm window, but the resulting WeChat mini-game context is not reliably recognized by the service.
- The WX launch path must be changed from "open shortcut directly" to an automated WeChat search flow.

Required target flow:

1. Start the local service first.
2. Wait until the gateway reaches the mini-game debug bridge / context waiting state.
3. Focus the WeChat desktop search box.
4. Search for `QQ经典农场` / `QQ农场`.
5. In the SouYiSou results window, select the mini-game tab.
6. Click the `QQ经典农场` mini-game result to enter the game.

## WX SouYiSou Launch Path Follow-up

Latest blocker:

- After WeChat was killed, reopened, and moved to another screen position, the
  launcher could focus WeChat but stopped after trying the sidebar SouYiSou
  entry.
- The desktop QQ Classic Farm shortcut was deleted during verification, so the
  launcher must not depend on shortcut fallback.

Fix applied:

- `src/process-guard-windows.js` now short-term raises the current WeChat main
  window before clicking sidebar entries, preventing the desktop shell or Codex
  window from stealing the click target.
- The SouYiSou sidebar entry is now clicked with UIAutomation-discovered
  coordinates and a real mouse click. The previous UIAutomation InvokePattern
  path could report success while WeChat did not open the SouYiSou window.
- Added a fallback main-window search path for states where SouYiSou opens inside
  the WeChat main window instead of a separate `WeChatAppEx` search window.
- WX launch still starts the service first and waits for the bridge/context wait
  state before opening the game.

Verification:

- Desktop shortcut check returned no `*QQ*农场*` shortcut on the desktop.
- With only the moved WeChat main window visible, direct
  `launchWeChatFarmViaSearch({}, 120000)` returned `ok=true`.
- The trace showed `wechat_souyisou_entry_clicked` with
  `mode=uia_real_click`, then `wx_search_window_ready`,
  `wx_search_query_submitted`, `wx_search_mini_game_tab_clicked`, and
  `wx_search_result_clicked`.
- The detected farm window was `WeChatAppEx`, title `QQ经典农场`, size
  `571x1039`.
- `http://127.0.0.1:8787/api/health` then reported
  `cdp.contextReady=true`, `readinessState=ready`,
  `executionContextId=7`, and `transportState.miniappConnected=true`.
7. Record the SouYiSou window PID / title / position / last successful keyword in stable user data.
8. On the first 90-minute relaunch and later relaunches, reuse the remembered SouYiSou window when possible, then click the mini-game result again.
9. Fall back to the full WeChat search flow if the remembered window is missing or stale.

Verification requirement:

- This must be proven on the current machine with the real WeChat UI before it is considered complete.
- A source-only structural test is not enough for acceptance.

Implementation progress:

- Added a Windows WeChat SouYiSou launcher in `src/process-guard-windows.js`.
- The launcher stores stable state in `data/wechat-search-launch-state.json`.
- The stored state includes the SouYiSou window handle, PID, title, position, keyword, result title, and the latest farm window information.
- The launcher also writes step-by-step trace events to `data/wechat-search-launch-state.json.trace.jsonl` while running.
- `performRuntimeRestart(..., "cdp")` now closes the current WX farm window by title/window handle first, then tries the WeChat SouYiSou launcher before the old desktop shortcut/protocol fallback.
- The desktop shell WX start flow now calls the same search-based `performRuntimeRestart(..., "cdp")` after the service reaches the mini-game bridge/context wait state.
- The search launcher does not assume the user already has SouYiSou open. If needed, it restores the WeChat main window, opens SouYiSou, searches for the farm, switches to the mini-game tab, and clicks the farm result.
- Real-machine testing showed that the SouYiSou window may return to the search home page after entering the farm, so the reuse path records the window/PID but still submits the keyword again before clicking the result.
- Real-machine testing showed that the farm window and SouYiSou window may share one `WeChatAppEx.exe` PID, so the relaunch path avoids killing the whole process when a close-window operation is enough.
- Farm-window detection now accepts either the `QQ经典农场` title or the typical vertical WeChat mini-game window size.

Real-machine evidence:

- Direct manual probe clicked the visible SouYiSou mini-game result and opened a `WeChatAppEx.exe` farm window titled `QQ经典农场`.
- `node -e "require('./src/process-guard-windows').launchWeChatFarmViaSearch(...)"` completed a full WeChat search flow from a minimized WeChat main window and wrote valid UTF-8 state to `data/wechat-search-launch-state.json`.
- The same launcher completed the reuse path from the saved SouYiSou window after the search page returned to its home state.
- `node -e "require('./src/process-guard').performRuntimeRestart({}, 'cdp')"` closed the current farm window and relaunched the farm through `wechat_search_reuse` without using the desktop shortcut fallback.
- `Windows_start.bat --wx` was restarted from a clean 8787 state. The service reached the WX bridge wait state, the normal entry triggered the saved SouYiSou window path, `wx_search_result_clicked` was recorded, and `/api/health` reached `cdp.contextReady=true` with `executionContextId=7`.
- Focused regression tests passed: `node scripts/test-scheduled-window-relaunch.cjs` and `node scripts/test-desktop-runtime-switch.cjs`.

Follow-up fix after shortcut deletion test:

- The WX automatic path no longer depends on the desktop `QQ经典农场` shortcut.
- Default `wxAllowLegacyLaunchFallback` is now `false`; if the WeChat search path fails, the runtime reports a search-launch failure and lets the gateway retry instead of silently falling back to the shortcut.
- The first-launch path now uses UI Automation to click the WeChat `搜一搜` sidebar button by name and center point. Fixed-coordinate fallback remains only behind that UIA attempt.
- Long Windows UI automation scripts now use a temporary UTF-16LE PowerShell `.ps1` file instead of `-EncodedCommand` when the encoded command would exceed the Windows command-line limit.
- Real-machine no-shortcut verification passed: with no matching desktop shortcut, no existing SouYiSou window, the launcher focused WeChat, clicked `搜一搜` via UIA, opened the search window, searched `QQ经典农场`, clicked the mini-game result, and opened the farm window.
- Real-machine normal-entry verification passed again: with no matching desktop shortcut, `Windows_start.bat --wx` reached `/api/health` `cdp.contextReady=true`, `executionContextId=7`, and trace recorded `wx_search_result_clicked`.

Boundaries:

- Do not modify `wmpf/`, `wmpf/frida/`, `wmpf/frida/config/addresses.*.json`, or `wmpf/frida/hook.js`.
- Keep QQ auto/manual host behavior separate from the WX scheduled relaunch path.

## v2.2 In Progress

Current user request:

1. Investigate why friend stealing sometimes steals blacklisted crops and why
   some mature friends never enter patrol even though their crops are mature.
   New follow-up: if the blacklist exposes an unknown/new crop component, record
   and update unknown crop-component diagnostics automatically instead of
   blindly stealing it.
2. Add a new Guard Dog option. When enabled, after scanning, active guard-dog
   friends should be automatically imported into the Web page friend-farm help
   list, so users do not need to add them one by one. When disabled, existing
   guard-dog-only extra-help behavior must remain unchanged.
3. Build and publish v2.2 protected release. Obfuscation must keep the previous
   protected-release strategy and use randomized output where the existing
   release pipeline supports it. Source package must remain private.

Progress so far:

- Inspected `src/auto-farm-executor.js`, `src/auto-farm-manager.js`,
  `src/friend-guard-dog-cache.js`, `src/gateway.js`, `public/index.html`, and
  friend-steal/guard-dog regression tests.
- Found a likely blacklisted-crop leak path: current regression
  `scripts/test-friend-steal-stability.cjs` still allows one-click harvest when
  plant blacklist is enabled but the live farm status has `workCounts.collect`
  with no detailed `grids`/`landIds`. That cannot prove the mature crop is safe,
  so v2.2 should change this to avoid one-click stealing when blacklist safety
  cannot be proven.
- Existing safe case remains valid: if detailed grid data proves the mature crop
  plant ID is not blacklisted, one-click harvest can remain allowed.
- Implemented unknown/new crop hot update for friend stealing:
  `src/unknown-crop-components.js` stores runtime-discovered mature actionable
  crop components in `data/unknown-crop-components.json`; `src/gateway.js`
  merges these records into the steal crop blacklist option list as
  `runtime_unknown_crop` entries; and `src/auto-farm-executor.js` blocks
  one-click stealing when blacklist safety cannot be proven.
- If an unknown/new crop has a concrete plant ID and land ID and that plant ID
  is not in the current blacklist, the executor now records the component first
  and performs one targeted steal for that land. If the crop identity or target
  land cannot be proven, it skips stealing with
  `blacklist_safety_unknown_crop` instead of risking a blacklisted one-click
  harvest.
- Focused tests passed for this change:
  `node scripts/test-unknown-crop-hot-update-steal.cjs`,
  `node scripts/test-unknown-crop-component-options.cjs`,
  `node scripts/test-friend-steal-blacklist-one-click.cjs`,
  `node scripts/test-friend-steal-stability.cjs`, and
  `node scripts/test-multi-tile-friend-steal.cjs`.
- Mature-friend-not-entering mitigation is implemented in
  `src/auto-farm-executor.js`: if a friend-status mature event supplies a
  `friendStealBurstGids` gid that is absent from the current friend-list cache,
  the patrol creates a temporary burst-only candidate and enters that friend
  farm to verify the live status. These burst probes are marked
  `burstProbe=true` and `cooldownEligible=false`, so a stale list miss cannot
  starve the friend and a failed probe does not create a long cooldown.
- `scripts/test-friend-steal-burst-gids.cjs` now covers both cases: a burst gid
  that exists in the friend list with collect count 0, and a burst gid missing
  from the friend list entirely.
- Guard-dog scan data already persists in `data/friend-guard-dog-cache.json`
  through `friend-guard-dog-cache.js`; active strong confirmed records are
  exposed by `getGuardDogRewardWhitelist(platform)`.
- The new Guard Dog auto-import switch is implemented as
  `autoFarmGuardDogAutoImportHelpList`, default off. The Web UI exposes it in
  the Guard Dog scan card. When enabled, a completed scan reads active strong
  confirmed guard-dog records and merges their gids into
  `autoFarmFriendWhitelist`, enables the whitelist, and ensures the `help`
  scope is present. When disabled, scans only update the guard-dog cache and
  keep the old guard-dog reward/help route unchanged.
- Focused tests passed for Guard Dog auto import and mature-event patrol:
  `node scripts/test-guard-dog-auto-import-config.cjs`,
  `node scripts/test-ui-guard-dog-scan.cjs`,
  `node scripts/test-friend-steal-burst-gids.cjs`,
  `node scripts/test-friend-steal-stability.cjs`, and
  `node scripts/test-user-settings-persistence.cjs`.
- Version and docs have been updated for v2.2 in `package.json`,
  `package-lock.json`, `README.md`, `CHANGELOG.md`, `AGENTS.md`, and
  `AI_AGENT_POLICY.md`.
- Additional release-adjacent regressions passed after the v2.2 work:
  `node scripts/test-desktop-runtime-switch.cjs` and
  `node scripts/test-scheduled-window-relaunch.cjs`.

Next steps:

1. Verify no WMPF/Frida paths changed.
2. Run release verification, then build/publish using
   `npm run release:dual -- --version 2.2`.

Current boundaries:

- Do not modify `wmpf/`, `wmpf/frida/`, `wmpf/frida/config/addresses.*.json`,
  or `wmpf/frida/hook.js`.
- Do not publish source artifacts publicly.
- Do not regress the completed WX SouYiSou launch fix; existing uncommitted
  files include that fix and must be preserved.
