"use strict";

const DEFAULT_SCENE_VALUES = Object.freeze([1005, 1007, 1008, 1027, 1035, 1053, 1074, 1145, 1178, 1256, 1260, 1302, 1308]);
const DEFAULT_TIMEOUT_MS = 90_000;

function normalizeSceneProfiles(profiles, baseOffset) {
  const unique = new Map();
  for (const raw of Array.isArray(profiles) ? profiles : []) {
    if (!Array.isArray(raw) || raw.length < 3) continue;
    const compact = raw.length >= 6
      ? raw.slice(0, 6)
      : [baseOffset, raw[0], 8, raw[1], 16, raw[2]];
    if (!compact.every((value) => Number.isInteger(value) && value >= 0 && value <= 0x10000)) continue;
    unique.set(compact.join(","), compact);
  }
  return [...unique.values()];
}

function buildProbeSource(input) {
  const payload = JSON.stringify(input);
  return `
    "use strict";
    const config = ${payload};
    const validScenes = new Set(config.sceneValues);
    const module = Process.getModuleByName("flue.dll");
    const readablePointer = (address) => {
      try {
        const range = Process.findRangeByAddress(address);
        return !!(range && range.protection.includes("r"));
      } catch (_) { return false; }
    };
    const readPointer = (address) => {
      try {
        if (!readablePointer(address)) return null;
        const value = address.readPointer();
        return value && !value.isNull() && readablePointer(value) ? value : null;
      } catch (_) { return null; }
    };
    const verify = (self, offsets) => {
      try {
        const p1 = readPointer(self.add(offsets[0])); if (!p1) return null;
        const p2 = readPointer(p1.add(offsets[1])); if (!p2) return null;
        const p3 = readPointer(p2.add(offsets[2])); if (!p3) return null;
        const p4 = readPointer(p3.add(offsets[3])); if (!p4) return null;
        const p5 = readPointer(p4.add(offsets[4])); if (!p5) return null;
        const valueAddress = p5.add(offsets[5]);
        if (!readablePointer(valueAddress)) return null;
        const scene = valueAddress.readInt();
        return validScenes.has(scene) ? scene : null;
      } catch (_) { return null; }
    };
    const adaptiveCandidates = (self) => {
      const matches = [];
      const base = config.sceneBaseOffset;
      const p1 = readPointer(self.add(base));
      if (!p1) return matches;
      for (let first = 256; first <= 2048; first += 8) {
        const p2 = readPointer(p1.add(first)); if (!p2) continue;
        for (const root of [0, 8, 16, 24, 32, 40, 48, 56, 64]) {
          const p3 = readPointer(p2.add(root)); if (!p3) continue;
          const secondStart = Math.max(256, first - 128);
          for (let second = secondStart; second <= first; second += 8) {
            const p4 = readPointer(p3.add(second)); if (!p4) continue;
            for (const valueRoot of [0, 8, 16, 24, 32, 40, 48, 56, 64]) {
              const p5 = readPointer(p4.add(valueRoot)); if (!p5) continue;
              const valueOffsets = [456, 488];
              for (let value = 0; value <= 640; value += 4) {
                if (value !== 456 && value !== 488) valueOffsets.push(value);
              }
              for (const value of valueOffsets) {
                const address = p5.add(value);
                if (!readablePointer(address)) continue;
                let scene = 0;
                try { scene = address.readInt(); } catch (_) { continue; }
                if (validScenes.has(scene)) matches.push({ offsets: [base, first, root, second, valueRoot, value], scene });
                if (matches.length > 8) return matches;
              }
            }
          }
        }
      }
      return matches;
    };
    let completed = false;
    Interceptor.attach(module.base.add(ptr(config.loadOffset)), {
      onEnter() {
        if (completed) return;
        const self = this.context.rcx;
        const known = [];
        for (const offsets of config.knownProfiles) {
          const scene = verify(self, offsets);
          if (scene !== null) known.push({ offsets, scene });
        }
        const matches = known.length ? known : adaptiveCandidates(self);
        const unique = new Map(matches.map((entry) => [entry.offsets.join(","), entry]));
        if (unique.size !== 1) {
          send({ type: "wmpf_local_scene_probe", status: "ambiguous", candidateCount: unique.size });
          return;
        }
        completed = true;
        const selected = [...unique.values()][0];
        send({ type: "wmpf_local_scene_probe", status: "matched", sceneOffsets: selected.offsets, scene: selected.scene });
      }
    });
    send({ type: "wmpf_local_scene_probe", status: "armed" });
  `;
}

async function probeWmpfSceneProfile(options = {}) {
  const session = options.session;
  if (!session || typeof session.createScript !== "function") throw new Error("wmpf_local_scene_probe_session_missing");
  const loadOffset = String(options.loadOffset || "");
  if (!/^0x[0-9a-f]+$/i.test(loadOffset)) throw new Error("wmpf_local_scene_probe_load_offset_invalid");
  const sceneBaseOffset = Number(options.sceneBaseOffset);
  if (!Number.isInteger(sceneBaseOffset) || sceneBaseOffset < 0 || sceneBaseOffset > 0x1000) {
    throw new Error("wmpf_local_scene_probe_base_invalid");
  }
  const knownProfiles = normalizeSceneProfiles(options.knownProfiles, sceneBaseOffset);
  const source = buildProbeSource({
    loadOffset,
    sceneBaseOffset,
    knownProfiles,
    sceneValues: DEFAULT_SCENE_VALUES,
  });
  const script = await session.createScript(source);
  const onStatus = typeof options.onStatus === "function" ? options.onStatus : () => {};
  const timeoutMs = Math.max(5_000, Number(options.timeoutMs) || DEFAULT_TIMEOUT_MS);
  try {
    const result = await new Promise((resolve, reject) => {
      let timer = null;
      const finish = (error, value) => {
        if (timer) clearTimeout(timer);
        error ? reject(error) : resolve(value);
      };
      script.message.connect((message) => {
        if (message && message.type === "error") {
          finish(new Error(`wmpf_local_scene_probe_script_error:${message.description || "unknown"}`));
          return;
        }
        const payload = message && message.payload;
        if (!payload || payload.type !== "wmpf_local_scene_probe") return;
        onStatus(payload);
        if (payload.status === "matched") finish(null, payload);
      });
      timer = setTimeout(() => finish(new Error("wmpf_local_scene_probe_timeout")), timeoutMs);
      void script.load().catch((error) => finish(error));
    });
    return result;
  } finally {
    await script.unload().catch(() => undefined);
  }
}

module.exports = {
  DEFAULT_SCENE_VALUES,
  DEFAULT_TIMEOUT_MS,
  normalizeSceneProfiles,
  probeWmpfSceneProfile,
};
