"use strict";

const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const { getWmpfAddressOverride } = require("./wmpf-address-overrides");
const { WMPF_ADDRESS_OVERRIDES } = require("./wmpf-address-overrides");
const { deriveLocalWmpfFunctions } = require("./wmpf-local-profile-deriver");
const { probeWmpfSceneProfile } = require("./wmpf-scene-profile-probe");

const TRUSTED_PROFILE_BASE_URL = "https://raw.githubusercontent.com/evi0s/WMPFDebugger/main/frida/config";
const PROFILE_FETCH_TIMEOUT_MS = 6000;
const PROFILE_MAX_BYTES = 16 * 1024;

function normalizeVersion(value) {
  const version = Number(value);
  return Number.isInteger(version) && version >= 10000 && version <= 99999 ? version : 0;
}

function validateWmpfAddressProfile(value, expectedVersion) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error("wmpf_address_profile_invalid_object");
  }
  const version = normalizeVersion(value.Version);
  if (!version || version !== normalizeVersion(expectedVersion)) {
    throw new Error(`wmpf_address_profile_version_mismatch:${version || "invalid"}`);
  }
  for (const field of ["LoadStartHookOffset", "CDPFilterHookOffset"]) {
    if (!/^0x[0-9a-f]+$/i.test(String(value[field] || ""))) {
      throw new Error(`wmpf_address_profile_invalid_${field}`);
    }
  }
  const sceneOffsets = Array.isArray(value.SceneOffsets) ? value.SceneOffsets : [];
  if (sceneOffsets.length < 3 || sceneOffsets.length > 8
    || !sceneOffsets.every((offset) => Number.isInteger(offset) && offset >= 0 && offset <= 0x10000)) {
    throw new Error("wmpf_address_profile_invalid_SceneOffsets");
  }
  const profile = {
    Version: version,
    LoadStartHookOffset: String(value.LoadStartHookOffset),
    CDPFilterHookOffset: String(value.CDPFilterHookOffset),
    SceneOffsets: sceneOffsets.slice(),
  };
  if (value.SceneBaseOffset != null) {
    const sceneBaseOffset = Number(value.SceneBaseOffset);
    if (!Number.isInteger(sceneBaseOffset) || sceneBaseOffset < 0 || sceneBaseOffset > 0x10000) {
      throw new Error("wmpf_address_profile_invalid_SceneBaseOffset");
    }
    profile.SceneBaseOffset = sceneBaseOffset;
  }
  if (Array.isArray(value.ScenePathOffsets)) {
    if (value.ScenePathOffsets.length < 1 || value.ScenePathOffsets.length > 8
      || !value.ScenePathOffsets.every((offset) => Number.isInteger(offset) && offset >= 0 && offset <= 0x10000)) {
      throw new Error("wmpf_address_profile_invalid_ScenePathOffsets");
    }
    profile.ScenePathOffsets = value.ScenePathOffsets.slice();
  }
  return profile;
}

function defaultCacheRoot() {
  const localAppData = String(process.env.LOCALAPPDATA || "").trim();
  return path.join(localAppData || path.join(os.homedir(), ".qq-farm-cdp-manager"), "QQ-Farm-CDP-Manager", "wmpf-address-cache");
}

function readProfileFile(filePath, version) {
  if (!filePath || !fs.existsSync(filePath)) return null;
  const text = fs.readFileSync(filePath, "utf8");
  if (Buffer.byteLength(text, "utf8") > PROFILE_MAX_BYTES) {
    throw new Error("wmpf_address_profile_too_large");
  }
  return validateWmpfAddressProfile(JSON.parse(text), version);
}

function writeCachedProfile(cachePath, profile) {
  fs.mkdirSync(path.dirname(cachePath), { recursive: true });
  const temporary = `${cachePath}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(temporary, `${JSON.stringify(profile, null, 2)}\n`, "utf8");
  fs.renameSync(temporary, cachePath);
}

function readDerivedProfile(cachePath, version, derived) {
  if (!fs.existsSync(cachePath)) return null;
  const envelope = JSON.parse(fs.readFileSync(cachePath, "utf8"));
  if (!envelope || envelope.schema !== 1 || normalizeVersion(envelope.version) !== version
    || !/^[0-9a-f]{64}$/i.test(String(envelope.binarySha256 || ""))
    || String(envelope.binarySha256).toLowerCase() !== String(derived.binarySha256).toLowerCase()) {
    throw new Error("wmpf_local_derived_cache_identity_mismatch");
  }
  const profile = validateWmpfAddressProfile(envelope.profile, version);
  if (profile.LoadStartHookOffset.toLowerCase() !== String(derived.LoadStartHookOffset).toLowerCase()
    || profile.CDPFilterHookOffset.toLowerCase() !== String(derived.CDPFilterHookOffset).toLowerCase()) {
    throw new Error("wmpf_local_derived_cache_function_mismatch");
  }
  return profile;
}

function writeDerivedProfile(cachePath, version, derived, profile) {
  fs.mkdirSync(path.dirname(cachePath), { recursive: true });
  const envelope = {
    schema: 1,
    version,
    binarySha256: derived.binarySha256,
    binarySize: derived.binarySize,
    derivedAt: new Date().toISOString(),
    evidence: derived.evidence,
    profile,
  };
  const temporary = `${cachePath}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(temporary, `${JSON.stringify(envelope, null, 2)}\n`, "utf8");
  fs.renameSync(temporary, cachePath);
}

function knownSceneProfiles(excludedVersion) {
  const unique = new Map();
  for (const [rawVersion, value] of Object.entries(WMPF_ADDRESS_OVERRIDES)) {
    if (Number(rawVersion) === Number(excludedVersion) || !value || !Array.isArray(value.SceneOffsets)) continue;
    unique.set(value.SceneOffsets.join(","), Array.from(value.SceneOffsets));
  }
  return [...unique.values()];
}

async function deriveLocalProfile(version, options, cacheRoot) {
  const deriveImpl = options.deriveLocalFunctionsImpl || deriveLocalWmpfFunctions;
  const probeImpl = options.probeSceneProfileImpl || probeWmpfSceneProfile;
  const derived = deriveImpl({ processPath: options.processPath, binaryPath: options.binaryPath });
  const cachePath = path.join(cacheRoot, `derived-addresses.${version}.json`);
  try {
    const cached = readDerivedProfile(cachePath, version, derived);
    if (cached) return { profile: cached, source: "local_derived_cached", path: cachePath, derived };
  } catch (error) {
    if (options.logger) options.logger.error(`[frida] local-derived WMPF cache rejected: ${String(error.message || error)}`);
  }
  const probe = await probeImpl({
    session: options.session,
    loadOffset: derived.LoadStartHookOffset,
    sceneBaseOffset: derived.sceneBaseOffset,
    knownProfiles: knownSceneProfiles(version),
    timeoutMs: options.localProbeTimeoutMs,
    onStatus: (status) => {
      if (options.logger) options.logger.info(`[frida] local WMPF scene probe: ${JSON.stringify(status)}`);
      if (typeof options.onLocalProbeStatus === "function") options.onLocalProbeStatus(status);
    },
  });
  const profile = validateWmpfAddressProfile({
    Version: version,
    LoadStartHookOffset: derived.LoadStartHookOffset,
    CDPFilterHookOffset: derived.CDPFilterHookOffset,
    SceneOffsets: probe.sceneOffsets,
  }, version);
  writeDerivedProfile(cachePath, version, derived, profile);
  return { profile, source: "local_binary_derived_verified", path: cachePath, derived, probe };
}

async function fetchTrustedProfile(version, options = {}) {
  const fetchImpl = options.fetchImpl || globalThis.fetch;
  if (typeof fetchImpl !== "function") throw new Error("wmpf_address_profile_fetch_unavailable");
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), Math.max(1000, Number(options.timeoutMs) || PROFILE_FETCH_TIMEOUT_MS));
  try {
    const url = `${TRUSTED_PROFILE_BASE_URL}/addresses.${version}.json`;
    const response = await fetchImpl(url, {
      method: "GET",
      redirect: "error",
      signal: controller.signal,
      headers: { Accept: "application/json" },
    });
    if (!response || response.ok !== true) {
      throw new Error(`wmpf_address_profile_http_${response && response.status || "failed"}`);
    }
    const text = await response.text();
    if (Buffer.byteLength(text, "utf8") > PROFILE_MAX_BYTES) {
      throw new Error("wmpf_address_profile_too_large");
    }
    return validateWmpfAddressProfile(JSON.parse(text), version);
  } finally {
    clearTimeout(timeout);
  }
}

async function resolveWmpfAddressProfile(options = {}) {
  const version = normalizeVersion(options.version);
  if (!version) throw new Error("wmpf_address_profile_version_invalid");
  const projectRoot = options.projectRoot || path.join(__dirname, "..");
  const localPath = path.join(projectRoot, "frida", "config", `addresses.${version}.json`);
  const cacheRoot = options.cacheRoot || defaultCacheRoot();
  const cachePath = path.join(cacheRoot, `addresses.${version}.json`);
  const logger = options.logger || null;
  const forcedVersion = normalizeVersion(options.forceLocalDerivationVersion
    || process.env.FARM_WMPF_FORCE_LOCAL_DERIVATION);
  const forceLocalDerivation = options.forceLocalDerivation === true || forcedVersion === version;

  if (!forceLocalDerivation) {
    const localProfile = readProfileFile(localPath, version);
    if (localProfile) return { profile: localProfile, source: "packaged_exact", path: localPath };

    const embeddedProfile = getWmpfAddressOverride(version);
    if (embeddedProfile) {
      return {
        profile: validateWmpfAddressProfile(embeddedProfile, version),
        source: "embedded_exact",
        path: null,
      };
    }

    try {
      const cachedProfile = readProfileFile(cachePath, version);
      if (cachedProfile) return { profile: cachedProfile, source: "cached_exact", path: cachePath };
    } catch (error) {
      if (logger) logger.error(`[frida] cached WMPF profile rejected: ${String(error.message || error)}`);
    }
  }

  let upstreamError = null;
  if (!forceLocalDerivation) {
    try {
      const remoteProfile = await fetchTrustedProfile(version, options);
      writeCachedProfile(cachePath, remoteProfile);
      return { profile: remoteProfile, source: "trusted_upstream_exact", path: cachePath };
    } catch (error) {
      upstreamError = error;
      if (logger) logger.info(`[frida] exact WMPF profile unavailable; trying verified local derivation: ${String(error.message || error)}`);
    }
  }

  try {
    return await deriveLocalProfile(version, options, cacheRoot);
  } catch (error) {
    const localReason = String(error instanceof Error ? error.message : error);
    const upstreamReason = upstreamError ? String(upstreamError instanceof Error ? upstreamError.message : upstreamError) : null;
    const reason = upstreamReason ? `${upstreamReason};local=${localReason}` : localReason;
    const unavailable = new Error(`wmpf_exact_address_profile_unavailable:${version}:${reason}`);
    unavailable.code = "wmpf_exact_address_profile_unavailable";
    unavailable.cause = error;
    throw unavailable;
  }
}

module.exports = {
  PROFILE_FETCH_TIMEOUT_MS,
  TRUSTED_PROFILE_BASE_URL,
  deriveLocalProfile,
  fetchTrustedProfile,
  knownSceneProfiles,
  readDerivedProfile,
  resolveWmpfAddressProfile,
  validateWmpfAddressProfile,
};
