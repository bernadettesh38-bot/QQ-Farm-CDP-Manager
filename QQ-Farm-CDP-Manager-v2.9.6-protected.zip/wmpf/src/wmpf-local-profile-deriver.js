"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");

const LOAD_START_ANCHOR = "virtual void applet::AppletIndexContainer::OnLoadStart(bool, const std::string &)";
const CDP_FILTER_ANCHOR = "SendToClientFilter";
const LEA_RIP_PREFIXES = Object.freeze([
  Buffer.from([0x48, 0x8d, 0x05]), Buffer.from([0x48, 0x8d, 0x0d]),
  Buffer.from([0x48, 0x8d, 0x15]), Buffer.from([0x48, 0x8d, 0x1d]),
  Buffer.from([0x4c, 0x8d, 0x05]), Buffer.from([0x4c, 0x8d, 0x0d]),
  Buffer.from([0x4c, 0x8d, 0x15]), Buffer.from([0x4c, 0x8d, 0x1d]),
]);

function localDerivationError(code, detail = "") {
  const error = new Error(`${code}${detail ? `:${detail}` : ""}`);
  error.code = code;
  return error;
}

function parsePeImage(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 1024 || buffer.toString("ascii", 0, 2) !== "MZ") {
    throw localDerivationError("wmpf_local_pe_invalid_dos_header");
  }
  const peOffset = buffer.readUInt32LE(0x3c);
  if (peOffset < 64 || peOffset + 24 >= buffer.length || buffer.toString("ascii", peOffset, peOffset + 4) !== "PE\0\0") {
    throw localDerivationError("wmpf_local_pe_invalid_nt_header");
  }
  const coffOffset = peOffset + 4;
  const sectionCount = buffer.readUInt16LE(coffOffset + 2);
  const optionalHeaderSize = buffer.readUInt16LE(coffOffset + 16);
  const sectionTableOffset = coffOffset + 20 + optionalHeaderSize;
  if (sectionCount < 2 || sectionCount > 96 || sectionTableOffset + sectionCount * 40 > buffer.length) {
    throw localDerivationError("wmpf_local_pe_invalid_section_table");
  }
  const sections = [];
  for (let index = 0; index < sectionCount; index += 1) {
    const offset = sectionTableOffset + index * 40;
    const name = buffer.subarray(offset, offset + 8).toString("ascii").replace(/\0+$/, "");
    const virtualSize = buffer.readUInt32LE(offset + 8);
    const virtualAddress = buffer.readUInt32LE(offset + 12);
    const rawSize = buffer.readUInt32LE(offset + 16);
    const rawOffset = buffer.readUInt32LE(offset + 20);
    if (rawOffset + rawSize > buffer.length) throw localDerivationError("wmpf_local_pe_section_out_of_range", name);
    sections.push({ name, virtualSize, virtualAddress, rawSize, rawOffset });
  }
  const text = sections.find((section) => section.name === ".text");
  const pdata = sections.find((section) => section.name === ".pdata");
  if (!text || !pdata || pdata.rawSize < 12) throw localDerivationError("wmpf_local_pe_required_section_missing");
  return { sections, text, pdata };
}

function offsetToRva(pe, offset) {
  const section = pe.sections.find((item) => offset >= item.rawOffset && offset < item.rawOffset + item.rawSize);
  return section ? section.virtualAddress + offset - section.rawOffset : -1;
}

function findUniqueAsciiAnchor(buffer, pe, anchor) {
  const needle = Buffer.from(anchor, "utf8");
  const first = buffer.indexOf(needle);
  if (first < 0) throw localDerivationError("wmpf_local_anchor_missing", anchor);
  if (buffer.indexOf(needle, first + 1) >= 0) throw localDerivationError("wmpf_local_anchor_ambiguous", anchor);
  const rva = offsetToRva(pe, first);
  if (rva < 0) throw localDerivationError("wmpf_local_anchor_not_mapped", anchor);
  return rva;
}

function findRuntimeFunction(buffer, pdata, instructionRva) {
  let low = 0;
  let high = Math.floor(pdata.rawSize / 12) - 1;
  while (low <= high) {
    const middle = (low + high) >> 1;
    const offset = pdata.rawOffset + middle * 12;
    const begin = buffer.readUInt32LE(offset);
    const end = buffer.readUInt32LE(offset + 4);
    if (instructionRva < begin) high = middle - 1;
    else if (instructionRva >= end) low = middle + 1;
    else return { begin, end };
  }
  throw localDerivationError("wmpf_local_runtime_function_missing", `0x${instructionRva.toString(16)}`);
}

function findUniqueAnchorFunction(buffer, pe, anchor) {
  const anchorRva = findUniqueAsciiAnchor(buffer, pe, anchor);
  const matches = [];
  for (const prefix of LEA_RIP_PREFIXES) {
    let rawOffset = pe.text.rawOffset;
    const rawEnd = pe.text.rawOffset + pe.text.rawSize;
    while ((rawOffset = buffer.indexOf(prefix, rawOffset)) >= 0 && rawOffset < rawEnd) {
      const instructionRva = pe.text.virtualAddress + rawOffset - pe.text.rawOffset;
      const targetRva = instructionRva + 7 + buffer.readInt32LE(rawOffset + 3);
      if (targetRva === anchorRva) {
        const fn = findRuntimeFunction(buffer, pe.pdata, instructionRva);
        matches.push({ instructionRva, begin: fn.begin, end: fn.end });
      }
      rawOffset += prefix.length;
    }
  }
  const uniqueBegins = [...new Set(matches.map((match) => match.begin))];
  if (uniqueBegins.length !== 1) {
    throw localDerivationError("wmpf_local_function_xref_not_unique", `${anchor}:${uniqueBegins.length}`);
  }
  const selected = matches.find((match) => match.begin === uniqueBegins[0]);
  return { ...selected, anchorRva };
}

function rvaToOffset(pe, rva) {
  const section = pe.sections.find((item) => rva >= item.virtualAddress && rva < item.virtualAddress + item.rawSize);
  if (!section) throw localDerivationError("wmpf_local_rva_not_mapped", `0x${rva.toString(16)}`);
  return section.rawOffset + rva - section.virtualAddress;
}

function deriveSceneBaseOffset(buffer, pe, loadFunction) {
  const start = rvaToOffset(pe, loadFunction.begin);
  const end = Math.min(rvaToOffset(pe, loadFunction.end), start + 384);
  const body = buffer.subarray(start, end);
  const candidates = [];
  for (let offset = 0; offset + 4 <= body.length; offset += 1) {
    if (body[offset] === 0x48 && body[offset + 1] === 0x8b && body[offset + 2] === 0x46) {
      candidates.push(body[offset + 3]);
    } else if (offset + 7 <= body.length && body[offset] === 0x48 && body[offset + 1] === 0x8b && body[offset + 2] === 0x86) {
      candidates.push(body.readUInt32LE(offset + 3));
    }
  }
  const plausible = [...new Set(candidates.filter((value) => value >= 32 && value <= 256 && value % 8 === 0))];
  if (plausible.length !== 1) {
    throw localDerivationError("wmpf_local_scene_base_not_unique", plausible.join(",") || "none");
  }
  return plausible[0];
}

function resolveFluePath(processPath) {
  const candidate = String(processPath || "").trim();
  if (!candidate) throw localDerivationError("wmpf_local_process_path_missing");
  const binaryPath = path.basename(candidate).toLowerCase() === "flue.dll"
    ? candidate
    : path.join(path.dirname(candidate), "flue.dll");
  if (!fs.existsSync(binaryPath)) throw localDerivationError("wmpf_local_flue_missing", binaryPath);
  return binaryPath;
}

function deriveLocalWmpfFunctions(options = {}) {
  const binaryPath = resolveFluePath(options.processPath || options.binaryPath);
  const buffer = fs.readFileSync(binaryPath);
  const pe = parsePeImage(buffer);
  const loadFunction = findUniqueAnchorFunction(buffer, pe, LOAD_START_ANCHOR);
  const cdpFunction = findUniqueAnchorFunction(buffer, pe, CDP_FILTER_ANCHOR);
  const sceneBaseOffset = deriveSceneBaseOffset(buffer, pe, loadFunction);
  return {
    binaryPath,
    binarySize: buffer.length,
    binarySha256: crypto.createHash("sha256").update(buffer).digest("hex"),
    LoadStartHookOffset: `0x${loadFunction.begin.toString(16).toUpperCase()}`,
    CDPFilterHookOffset: `0x${cdpFunction.begin.toString(16).toUpperCase()}`,
    sceneBaseOffset,
    evidence: {
      loadAnchorRva: `0x${loadFunction.anchorRva.toString(16).toUpperCase()}`,
      loadXrefRva: `0x${loadFunction.instructionRva.toString(16).toUpperCase()}`,
      cdpAnchorRva: `0x${cdpFunction.anchorRva.toString(16).toUpperCase()}`,
      cdpXrefRva: `0x${cdpFunction.instructionRva.toString(16).toUpperCase()}`,
    },
  };
}

module.exports = {
  CDP_FILTER_ANCHOR,
  LOAD_START_ANCHOR,
  deriveLocalWmpfFunctions,
  parsePeImage,
  resolveFluePath,
};
