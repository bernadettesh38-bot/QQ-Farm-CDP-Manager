// 水印：二开倒卖先别急，README 都没看明白就上链接，属实有点绷不住。
"use strict";
require("../../load-env.cjs").loadEnvFiles(require("node:path").join(__dirname, "..", ".."));
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_fs_1 = require("node:fs");
const node_events_1 = require("node:events");
const node_path_1 = __importDefault(require("node:path"));
const frida = __importStar(require("frida"));
const ws_1 = __importStar(require("ws"));
const cli_1 = require("./cli");
const logger_1 = require("./logger");
const cdp_automation_1 = require("./cdp_automation");
const compat_runtime_1 = require("./compat-runtime");
const cdp_replay_1 = require("./cdp-replay");
const process_discovery_1 = require("./process-discovery");
const { resolveWmpfAddressProfile } = require("./wmpf-address-profile-resolver");
const codex = require("./third-party/RemoteDebugCodex.js");
const messageProto = require("./third-party/WARemoteDebugProtobuf.js");
const FRIDA_RETRY_MS = 3000;
const waitForFridaSessionDetach = (session) => new Promise((_, reject) => {
    session.detached.connect((reason, crash) => {
        const crashSummary = crash && typeof crash === "object"
            ? ` crash=${JSON.stringify(crash)}`
            : "";
        reject(new Error(`[frida] session detached: ${String(reason ?? "unknown")}${crashSummary}`));
    });
});
class DebugMessageEmitter extends node_events_1.EventEmitter {
}
const debugMessageEmitter = new DebugMessageEmitter();
debugMessageEmitter.transportState = {
    miniappClientCount: 0,
    miniappConnected: false,
    cdpClientCount: 0,
    cdpClientConnected: false,
    lastMiniappConnectedAt: null,
    lastMiniappDisconnectedAt: null,
    lastMiniappScene: null,
    lastMiniappScenePatchedAt: null,
    lastFridaMessage: null,
    lastMiniappCategory: null,
    miniappProtocolReady: false,
    replayedCdpCommandCount: 0,
    lastCdpReplayAt: null,
    fridaState: "idle",
    fridaAttempt: 0,
    fridaPid: null,
    fridaWmpfVersion: null,
    fridaAddressSource: null,
    fridaAddressProfileVersion: null,
    lastFridaAttachAt: null,
    lastFridaReadyAt: null,
    lastFridaError: null,
    fridaNextRetryAt: null,
};
const update_frida_state = (patch) => {
    Object.assign(debugMessageEmitter.transportState, patch);
    debugMessageEmitter.emit("fridastatechange", {
        ...debugMessageEmitter.transportState,
    });
};
const update_transport_state_from_frida = (payload, logger) => {
    const text = typeof payload === "string" ? payload : String(payload ?? "");
    debugMessageEmitter.transportState.lastFridaMessage = text;
    const sceneMatch = text.match(/\[hook\] scene: (-?\d+)/);
    if (sceneMatch) {
        const sceneNumber = Number(sceneMatch[1]);
        if (Number.isFinite(sceneNumber)) {
            debugMessageEmitter.transportState.lastMiniappScene = sceneNumber;
            logger.info(`[frida] miniapp scene detected: ${sceneNumber}`);
        }
        return;
    }
    if (text.includes("[hook] hook scene condition -> 1101")) {
        debugMessageEmitter.transportState.lastMiniappScenePatchedAt = new Date().toISOString();
        logger.info("[frida] miniapp scene patched -> 1101");
    }
};
const bufferToHexString = (buffer) => {
    return Array.from(new Uint8Array(buffer))
        .map((byte) => byte.toString(16).padStart(2, "0"))
        .join("");
};
const safe_json_parse = (payload) => {
    try {
        return JSON.parse(payload);
    }
    catch (_) {
        return null;
    }
};
const summarize_console_args = (args) => args
    .slice(0, 3)
    .map((arg) => {
    if (!arg || typeof arg !== "object") {
        return String(arg);
    }
    const item = arg;
    if (typeof item.value === "string") {
        return item.value;
    }
    if (typeof item.value === "number" ||
        typeof item.value === "boolean") {
        return String(item.value);
    }
    if (typeof item.description === "string" && item.description.length > 0) {
        return item.description;
    }
    return item.type ?? "unknown";
})
    .join(" | ");
const summarize_cdp_payload = (payloadText) => {
    const payload = safe_json_parse(payloadText);
    if (!payload) {
        return `[miniapp] [DEBUG] cdp payload (non-json): ${payloadText.slice(0, 160)}`;
    }
    if (typeof payload.method === "string") {
        if (payload.method === "Runtime.consoleAPICalled") {
            const type = payload.params?.type;
            if (type === "trace" ||
                type === "log" ||
                type === "debug" ||
                type === "info") {
                return null;
            }
            return `[miniapp] [DEBUG] cdp event Runtime.consoleAPICalled type=${type ?? "unknown"} context=${payload.params?.executionContextId ?? "?"} args=${summarize_console_args(Array.isArray(payload.params?.args) ? payload.params.args : [])}`;
        }
        if (payload.method === "Runtime.executionContextCreated") {
            const context = payload.params?.context ?? {};
            return `[miniapp] [DEBUG] cdp event Runtime.executionContextCreated id=${context.id ?? "?"} name=${context.name ?? ""} origin=${context.origin ?? ""}`;
        }
        if (payload.method === "Runtime.executionContextDestroyed") {
            return `[miniapp] [DEBUG] cdp event Runtime.executionContextDestroyed id=${payload.params?.executionContextId ?? "?"}`;
        }
        if (payload.method === "Runtime.executionContextsCleared") {
            return "[miniapp] [DEBUG] cdp event Runtime.executionContextsCleared";
        }
        if (payload.method === "Runtime.exceptionThrown") {
            return `[miniapp] [DEBUG] cdp event Runtime.exceptionThrown text=${payload.params?.exceptionDetails?.text ?? ""}`;
        }
        return `[miniapp] [DEBUG] cdp event ${payload.method}`;
    }
    if (typeof payload.id === "number") {
        if (payload.error) {
            return `[miniapp] [DEBUG] cdp response id=${payload.id} error=${payload.error.message ?? "unknown error"}`;
        }
        return `[miniapp] [DEBUG] cdp response id=${payload.id}`;
    }
    return "[miniapp] [DEBUG] cdp payload";
};
const summarize_debug_message = (message) => {
    if (!message || typeof message !== "object") {
        return String(message);
    }
    const category = message.category;
    const data = message.data ?? {};
    switch (category) {
        case "setupContext":
            return `[miniapp] [DEBUG] setupContext configure_js_len=${typeof data.configure_js === "string" ? data.configure_js.length : 0} register_interface=${data.register_interface?.obj_name ?? "<unknown>"}`;
        case "addJsContext":
            return `[miniapp] [DEBUG] addJsContext id=${data.jscontext_id ?? ""} name=${data.jscontext_name ?? ""}`;
        case "removeJsContext":
            return `[miniapp] [DEBUG] removeJsContext id=${data.jscontext_id ?? ""}`;
        case "connectJsContext":
            return `[miniapp] [DEBUG] connectJsContext id=${data.jscontext_id ?? ""}`;
        case "chromeDevtools":
            return `[miniapp] [DEBUG] outbound cdp jscontext_id=${data.jscontext_id ?? ""}`;
        case "chromeDevtoolsResult":
            if (typeof data.payload === "string") {
                return summarize_cdp_payload(data.payload);
            }
            return "[miniapp] [DEBUG] chromeDevtoolsResult";
        default:
            return `[miniapp] [DEBUG] ${String(category ?? "unknown")}`;
    }
};
const debug_server = (options, logger) => {
    const wss = new ws_1.WebSocketServer({ port: options.debugPort });
    logger.info(`[server] debug server running on ws://localhost:${options.debugPort}`);
    logger.info(`[server] debug server waiting for miniapp to connect...`);
    let messageCounter = 0;
    const replayableCdpMessages = new Map();
    let miniappProtocolReady = false;
    let activeMiniappClient = null;
    const sendToMiniappClient = (client, message) => {
        if (client.readyState !== ws_1.default.OPEN) {
            return;
        }
        let category = "chromeDevtools";
        let rawPayload;
        if (typeof message === "string") {
            rawPayload = {
                jscontext_id: "",
                op_id: Math.round(100 * Math.random()),
                payload: message.toString(),
            };
        }
        else {
            const data = message.data != null && typeof message.data === "object"
                ? message.data
                : {};
            category = message.category != null ? message.category : "chromeDevtools";
            if (category === "chromeDevtools") {
                rawPayload = {
                    jscontext_id: String(data.jscontext_id ?? ""),
                    op_id: Math.round(100 * Math.random()),
                    payload: String(data.payload ?? ""),
                };
            }
            else {
                rawPayload = {
                    jscontext_id: String(data.jscontext_id ?? ""),
                };
            }
        }
        logger.main_debug(rawPayload);
        const wrappedData = codex.wrapDebugMessageData(rawPayload, category, 0);
        const outData = {
            seq: ++messageCounter,
            category,
            data: wrappedData.buffer,
            compressAlgo: 0,
            originalSize: wrappedData.originalSize,
        };
        const encodedData = messageProto.mmbizwxadevremote.WARemoteDebug_DebugMessage.encode(outData).finish();
        client.send(encodedData, { binary: true });
    };
    const replayCdpInitialization = () => {
        const messages = Array.from(replayableCdpMessages.values());
        if (messages.length === 0) {
            return;
        }
        setImmediate(() => {
            let replayed = 0;
            const client = activeMiniappClient;
            if (client && client.readyState === ws_1.default.OPEN) {
                messages.forEach((message) => {
                    sendToMiniappClient(client, message);
                    replayed += 1;
                });
            }
            if (replayed > 0) {
                debugMessageEmitter.transportState.replayedCdpCommandCount += replayed;
                debugMessageEmitter.transportState.lastCdpReplayAt = new Date().toISOString();
                logger.info(`[miniapp] replayed ${replayed} CDP initialization command(s) after runtime became ready`);
            }
        });
    };
    const onMessage = (message) => {
        let unwrappedData = null;
        try {
            const decodedData = messageProto.mmbizwxadevremote.WARemoteDebug_DebugMessage.decode(message);
            unwrappedData = codex.unwrapDebugMessageData(decodedData);
            const summary = summarize_debug_message(unwrappedData);
            if (summary) {
                logger.main_debug(summary);
            }
        }
        catch (e) {
            logger.error(`[miniapp] miniapp client err: ${e}`);
            logger.main_debug(`[miniapp] undecoded raw message (hex): ${bufferToHexString(message).slice(0, 320)}`);
        }
        if (unwrappedData === null) {
            return;
        }
        debugMessageEmitter.transportState.lastMiniappCategory =
            String(unwrappedData.category ?? "");
        debugMessageEmitter.emit("miniappmessage", unwrappedData);
        if ((0, cdp_replay_1.isRuntimeReadyCategory)(unwrappedData.category)) {
            const wasReady = miniappProtocolReady;
            miniappProtocolReady = true;
            debugMessageEmitter.transportState.miniappProtocolReady = true;
            if (!wasReady) {
                replayCdpInitialization();
            }
        }
        if (unwrappedData.category === "chromeDevtoolsResult") {
            // need to proxy to CDP client
            debugMessageEmitter.emit("cdpmessage", unwrappedData.data.payload);
        }
    };
    wss.on("connection", (ws) => {
        const previousClient = activeMiniappClient;
        activeMiniappClient = ws;
        if (previousClient && previousClient !== ws && previousClient.readyState === ws_1.default.OPEN) {
            try {
                previousClient.close(1012, "superseded_miniapp_client");
            }
            catch (_) { }
        }
        logger.info("[miniapp] miniapp client connected");
        debugMessageEmitter.transportState.miniappClientCount += 1;
        debugMessageEmitter.transportState.miniappConnected =
            debugMessageEmitter.transportState.miniappClientCount > 0;
        debugMessageEmitter.transportState.lastMiniappConnectedAt = new Date().toISOString();
        miniappProtocolReady = false;
        debugMessageEmitter.transportState.miniappProtocolReady = false;
        debugMessageEmitter.emit("miniappconnected");
        ws.on("message", (message) => {
            if (ws !== activeMiniappClient) {
                return;
            }
            onMessage(message);
        });
        ws.on("error", (err) => {
            logger.error("[miniapp] miniapp client err:", err);
        });
        ws.on("close", () => {
            logger.info("[miniapp] miniapp client disconnected");
            debugMessageEmitter.transportState.miniappClientCount = Math.max(0, debugMessageEmitter.transportState.miniappClientCount - 1);
            debugMessageEmitter.transportState.miniappConnected =
                debugMessageEmitter.transportState.miniappClientCount > 0;
            debugMessageEmitter.transportState.lastMiniappDisconnectedAt = new Date().toISOString();
            if (ws !== activeMiniappClient) {
                return;
            }
            activeMiniappClient = null;
            if (debugMessageEmitter.transportState.miniappClientCount === 0) {
                miniappProtocolReady = false;
                debugMessageEmitter.transportState.miniappProtocolReady = false;
                debugMessageEmitter.emit("miniappdisconnected");
                return;
            }
            const remaining = Array.from(wss.clients).filter((client) => client.readyState === ws_1.default.OPEN);
            activeMiniappClient = remaining.length > 0 ? remaining[remaining.length - 1] : null;
            if (activeMiniappClient) {
                miniappProtocolReady = false;
                debugMessageEmitter.transportState.miniappProtocolReady = false;
                debugMessageEmitter.emit("miniappconnected");
                replayCdpInitialization();
            }
        });
    });
    debugMessageEmitter.on("proxymessage", (message) => {
        if ((0, cdp_replay_1.isReplayableCdpMessage)(message)) {
            const replayKey = (0, cdp_replay_1.getReplayKey)(message);
            if (replayKey) {
                replayableCdpMessages.set(replayKey, message);
            }
        }
        if (activeMiniappClient) {
            sendToMiniappClient(activeMiniappClient, message);
        }
    });
};
function wsMessageToUtf8(message) {
    if (Buffer.isBuffer(message))
        return message.toString("utf8");
    if (message instanceof ArrayBuffer)
        return Buffer.from(message).toString("utf8");
    if (typeof message === "string")
        return message;
    return String(message);
}
const proxy_server = (options, logger) => {
    const wss = new ws_1.WebSocketServer({ port: options.cdpPort });
    logger.info(`[server] proxy server running on ws://localhost:${options.cdpPort}`);
    logger.info(`[server] link: devtools://devtools/bundled/inspector.html?ws=127.0.0.1:${options.cdpPort}`);
    const onMessage = (message) => {
        /** ws 库常把文本帧当成 Buffer，必须转成 string，否则 proxymessage 走非 string 分支导致 payload 为空、CDP 永不回包 */
        debugMessageEmitter.emit("proxymessage", wsMessageToUtf8(message));
    };
    wss.on("connection", (ws) => {
        logger.info("[cdp] CDP client connected");
        debugMessageEmitter.transportState.cdpClientCount += 1;
        debugMessageEmitter.transportState.cdpClientConnected =
            debugMessageEmitter.transportState.cdpClientCount > 0;
        debugMessageEmitter.emit("cdpClientConnected", { ws });
        ws.on("message", onMessage);
        ws.on("error", (err) => {
            logger.error("[cdp] CDP client err:", err);
        });
        ws.on("close", () => {
            logger.info("[cdp] CDP client disconnected");
            debugMessageEmitter.transportState.cdpClientCount = Math.max(0, debugMessageEmitter.transportState.cdpClientCount - 1);
            debugMessageEmitter.transportState.cdpClientConnected =
                debugMessageEmitter.transportState.cdpClientCount > 0;
            debugMessageEmitter.emit("cdpClientDisconnected", { ws });
        });
    });
    debugMessageEmitter.on("cdpmessage", (message) => {
        wss &&
            wss.clients.forEach((client) => {
                if (client.readyState === ws_1.default.OPEN) {
                    // send CDP message to devtools
                    client.send(message);
                }
            });
    });
};
const frida_server = async (options, logger) => {
    const localDevice = await frida.getLocalDevice();
    const processes = await localDevice.enumerateProcesses({
        scope: frida.Scope.Metadata,
    });
    const environment = await (0, process_discovery_1.discoverWechatEnvironment)();
    const discoveredRoot = (0, process_discovery_1.selectWechatWmpfRootProcess)(environment.miniProgramProcesses);
    const discoveredPid = discoveredRoot ? Number(discoveredRoot.pid) : 0;
    const wmpfProcesses = processes.filter((process) => {
        if (process.name !== "WeChatAppEx.exe")
            return false;
        const processPath = String(process.parameters.path || "");
        return !/[\\/]QQ[\\/]|[\\/]versions[\\/].*[\\/]wmpfsdk[\\/]/i.test(processPath);
    });
    const fallbackParentPids = wmpfProcesses
        .map((process) => process.parameters.ppid ? Number(process.parameters.ppid) : 0)
        .filter((pid) => pid > 0);
    const fallbackPid = fallbackParentPids
        .sort((a, b) => fallbackParentPids.filter((value) => value === a).length -
        fallbackParentPids.filter((value) => value === b).length)
        .pop();
    const wmpfPid = discoveredPid > 0 && processes.some((process) => process.pid === discoveredPid)
        ? discoveredPid
        : fallbackPid;
    if (wmpfPid === undefined) {
        throw new Error("[frida] WeChatAppEx.exe process not found");
    }
    const wmpfProcess = processes.filter((process) => process.pid === wmpfPid)[0];
    if (!wmpfProcess) {
        throw new Error(`[frida] selected WeChatAppEx.exe process not found: ${wmpfPid}`);
    }
    const wmpfProcessPath = wmpfProcess.parameters.path;
    const wmpfVersionMatch = wmpfProcessPath
        ? wmpfProcessPath.match(/\d+/g)
        : "";
    const wmpfVersion = wmpfVersionMatch
        ? new Number(wmpfVersionMatch.pop())
        : 0;
    if (wmpfVersion === 0) {
        throw new Error("[frida] error in find wmpf version");
    }
    // attach to process
    update_frida_state({
        fridaState: "attaching",
        fridaPid: Number(wmpfPid),
        fridaWmpfVersion: Number(wmpfVersion),
        lastFridaAttachAt: new Date().toISOString(),
        lastFridaError: null,
        fridaNextRetryAt: null,
    });
    const session = await localDevice.attach(Number(wmpfPid));
    // find hook script（必须用 __dirname：从 run.cjs 入口 require 时 require.main 指向 run.cjs，会错到仓库外）
    const projectRoot = node_path_1.default.join(__dirname, "..");
    let scriptContent = null;
    try {
        scriptContent = (await node_fs_1.promises.readFile(node_path_1.default.join(projectRoot, "frida/hook.js"))).toString();
    }
    catch (e) {
        throw new Error("[frida] hook script not found");
        return;
    }
    const resolvedAddress = await resolveWmpfAddressProfile({
        version: Number(wmpfVersion),
        projectRoot,
        logger,
        session,
        processPath: wmpfProcessPath,
        onLocalProbeStatus: (status) => {
            if (status && status.status === "armed") update_frida_state({ fridaState: "local_probe_armed" });
            if (status && status.status === "matched") update_frida_state({ fridaState: "local_probe_verified" });
        },
    });
    const configContent = JSON.stringify(resolvedAddress.profile);
    update_frida_state({
        fridaAddressSource: resolvedAddress.source,
        fridaAddressProfileVersion: Number(resolvedAddress.profile.Version),
    });
    logger.info(`[frida] WMPF address profile ready: version=${wmpfVersion}, source=${resolvedAddress.source}`);
    if (resolvedAddress.source === "local_binary_derived_verified" || resolvedAddress.source === "local_derived_cached") {
        logger.info(`[frida] verified local WMPF adaptation active: version=${wmpfVersion}, binarySha256=${resolvedAddress.derived && resolvedAddress.derived.binarySha256 || "cache_verified"}`);
    }
    if (scriptContent === null || configContent === null) {
        throw new Error("[frida] unable to find hook script");
        return;
    }
    // load script
    const script = await session.createScript(scriptContent.replace("@@CONFIG@@", configContent));
    script.message.connect((message) => {
        if (message.type === "error") {
            logger.error("[frida client]", message);
            return;
        }
        update_transport_state_from_frida(message.payload, logger);
        logger.frida_debug("[frida client]", message.payload);
    });
    await script.load();
    update_frida_state({
        fridaState: "ready",
        fridaPid: Number(wmpfPid),
        fridaWmpfVersion: Number(wmpfVersion),
        lastFridaReadyAt: new Date().toISOString(),
        lastFridaError: null,
        fridaNextRetryAt: null,
    });
    logger.info(`[frida] script loaded, WMPF version: ${wmpfVersion}, pid: ${wmpfPid}`);
    logger.info(`[frida] you can now open any miniapps`);
    await waitForFridaSessionDetach(session);
};
const is_retryable_frida_error = (error) => {
    const message = String(error instanceof Error ? error.message : error).toLowerCase();
    return message.includes("wechatappex.exe process not found") ||
        message.includes("unable to attach") ||
        message.includes("process not found") ||
        message.includes("process has terminated") ||
        message.includes("refused to load frida-agent") ||
        message.includes("terminated during injection") ||
        message.includes("[frida] session detached:") ||
        message.includes("wmpf_exact_address_profile_unavailable:");
};
const get_frida_retry_ms = (error) => String(error instanceof Error ? error.message : error)
    .includes("wmpf_exact_address_profile_unavailable:")
    ? 5 * 60 * 1000
    : FRIDA_RETRY_MS;
const start_frida_server_with_retry = (options, logger) => {
    let attempt = 0;
    let lastMessage = "";
    void (async () => {
        while (true) {
            attempt += 1;
            update_frida_state({
                fridaState: "attaching",
                fridaAttempt: attempt,
                lastFridaError: null,
                fridaNextRetryAt: null,
            });
            try {
                await frida_server(options, logger);
                return;
            }
            catch (error) {
                const message = String(error instanceof Error ? error.message : error);
                if (!is_retryable_frida_error(error)) {
                    update_frida_state({
                        fridaState: "failed",
                        lastFridaError: message,
                        fridaNextRetryAt: null,
                    });
                    logger.error("[frida] startup failed:", error);
                    return;
                }
                const retryMs = get_frida_retry_ms(error);
                update_frida_state({
                    fridaState: "retry_wait",
                    lastFridaError: message,
                    fridaNextRetryAt: new Date(Date.now() + retryMs).toISOString(),
                });
                if (message !== lastMessage || attempt === 1) {
                    logger.info(`[frida] ${message}，${retryMs}ms 后重试`);
                    lastMessage = message;
                }
                await new Promise((resolve) => setTimeout(resolve, retryMs));
            }
        }
    })();
};
const main = async () => {
    const options = (0, cli_1.parse_cli_options)();
    const logger = (0, logger_1.create_logger)(options);
    debug_server(options, logger);
    proxy_server(options, logger);
    (0, cdp_automation_1.start_cdp_automation)(debugMessageEmitter, options, logger);
    start_frida_server_with_retry(options, logger);
};
(async () => {
    await main();
})();
exports.debugMessageEmitter = debugMessageEmitter;
exports.connect = (options = {}) => (0, compat_runtime_1.connect)(options, {
    transport: debugMessageEmitter,
});
exports.CompatRuntime = compat_runtime_1.CompatRuntime;
