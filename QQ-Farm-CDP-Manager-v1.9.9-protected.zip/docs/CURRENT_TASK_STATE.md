﻿# Current Task State

## Active Release Task: v1.9.9

Latest user requirements:

- Publish v1.9.9 after fixing the current live regressions.
- Web dashboard at http://127.0.0.1:8787 must persist light/dark theme. Saving config, starting/toggling automation, refreshing, or waiting must not switch the selected theme.
- Idle-disconnect prevention must use a real low-frequency manual-style interaction. Current implementation opens/waits/closes the warehouse first and uses the old lightweight click only as a fallback.
- Desktop shell must be usable: visible window, clickable buttons, version/status loaded, Settings works, service controls work.
- Desktop shell WX mode must start the local service first, wait for health readiness, then try the desktop QQ Classic Farm shortcut. If the shortcut is missing or launch fails, keep the manual-open fallback.
- Normal user startup through Windows_start.bat must still bring up services; do not rely on node run.cjs as the only path.
- Do not modify WMPF or Frida paths.
- Public release must include protected artifacts only. Source artifact remains private.

## Completed Changes

- Version bumped to 1.9.9 in package metadata.
- Web theme save path now preserves the effective UI theme when saving farm config.
- Partial config application no longer applies a default dark theme when uiTheme is absent.
- Idle keepalive now tries a real warehouse open/wait/close interaction and logs warehouseAttempt diagnostics.
- button-lite.js includes the idle keepalive warehouse open/close strings, so protected runtime is not left on the old synthetic-only path.
- Desktop shell UI was restored from the v1.9.7-hotfix source package style, keeping the animated top-left brand gif and the known no-drag clickable control model.
- Desktop shell Settings URL maps 0.0.0.0 / :: / * to 127.0.0.1 for local opening.
- Desktop shell WX service start order changed: spawn node run.cjs --wx, wait for /api/health, then launch the desktop QQ Classic Farm shortcut.
- README and CHANGELOG describe the service-first WX shortcut order.
- Added scripts/test-desktop-shell-click.cjs to smoke-test real Electron button clicks.
- Updated desktop runtime-switch/minimize tests for the restored shell and service-first WX order.

## Verification Completed

Focused local checks passed:

- node --check button.js and desktop shell files.
- node scripts/test-desktop-runtime-switch.cjs
- node scripts/test-desktop-minimize-button.cjs
- node scripts/test-desktop-close-exit.cjs
- Electron click smoke test: scripts/test-desktop-shell-click.cjs exited 0.
- node scripts/test-ui-theme.cjs
- node scripts/test-user-settings-persistence.cjs
- node scripts/test-idle-disconnect-watch.cjs

Live checks completed:

- Windows_start.bat --qq brought up the local service on 127.0.0.1:8787.
- Live API theme check passed: light stayed light after Web automation/config partial saves; dark stayed dark after another partial save.
- Live browser page check passed: after selecting light and saving partial config, reload still showed document data-theme=light and the theme select stayed light. The page was then restored to dark.

Release dry-run completed:

- npm.cmd run release:dual -- --version 1.9.9 --dry-run --allow-dirty passed.
- Dry-run build id: PUBLIC-20260623-005.
- Generated private source package and public protected package locally.
- Manifest verification, sensitive-data scan, public source-leak scan, tamper tests, protected runtime size tests, and release gates passed.
- Local protected test copy was skipped because F:\QQ-Farm-Protected-Tests is unavailable.

## Pending

- Commit the private source changes.
- Run formal npm.cmd run release:dual -- --version 1.9.9 from a clean worktree.
- Confirm public protected branch/tag/release upload completes.
- Report final artifact paths and GitHub publish result.

## Boundaries

- Do not modify wmpf/, wmpf/frida/, wmpf/frida/config/addresses.*.json, wmpf/frida/hook.js, WMPF patch scenes, or ExtraPatchSceneNumbers.
- Do not publish source artifacts to the public repository.
- Do not force-push or rewrite public protected-release history.
- Public docs must remain clean UTF-8. If Chinese cannot be verified readable, use English.
