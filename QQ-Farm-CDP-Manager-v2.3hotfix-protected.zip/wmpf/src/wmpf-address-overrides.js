"use strict";

const WMPF_ADDRESS_OVERRIDES = Object.freeze({
  20001: Object.freeze({
    Version: 20001,
    LoadStartHookOffset: "0x25D1520",
    CDPFilterHookOffset: "0x30B03A0",
    SceneOffsets: Object.freeze([64, 1480, 8, 1416, 16, 456]),
  }),
  20005: Object.freeze({
    Version: 20005,
    LoadStartHookOffset: "0x25DBBE0",
    CDPFilterHookOffset: "0x30C5D90",
    SceneOffsets: Object.freeze([64, 1480, 8, 1416, 16, 456]),
  }),
});

function getWmpfAddressOverride(version) {
  const key = Number(version);
  const value = WMPF_ADDRESS_OVERRIDES[key];
  if (!value) return null;
  return {
    Version: value.Version,
    LoadStartHookOffset: value.LoadStartHookOffset,
    CDPFilterHookOffset: value.CDPFilterHookOffset,
    SceneOffsets: Array.from(value.SceneOffsets),
  };
}

module.exports = {
  WMPF_ADDRESS_OVERRIDES,
  getWmpfAddressOverride,
};
